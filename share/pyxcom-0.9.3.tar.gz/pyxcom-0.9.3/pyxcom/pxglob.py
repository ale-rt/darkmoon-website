## -----------------------------------
## This is a global library for pyxcom
## -----------------------------------
## Copyright (c) 2004-2007 Alessandro Pisa <alessandro...pisa@@@gmail...com>
## All rights reserved.
##
## Redistribution and use in source and binary forms, with or without
## modification, are permitted provided that the following conditions
## are met:
##
## 1. Redistributions of source code must retain the above copyright
##    notice, this list of conditions and the following disclaimer.
## 2. Redistributions in binary form must reproduce the above copyright
##    notice, this list of conditions and the following disclaimer in the
##    documentation and/or other materials provided with the distribution.
##
## THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
## IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
## OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
## IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
## INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
## NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
## DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
## THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
## (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
## THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import os, sys, getopt

# URL to xcom package at nist website
XCOM_URL='http://physics.nist.gov/PhysRefData/Xcom/XCOM.tar.gz'

# Name and meaning of the colums
COLUMNS_LEGEND=('Photon Energy (MeV)',
                'Coherent Scattering (cm2/g)',
                'Incoherent Scattering (cm2/g)',
                'Photoelectric Absorption (cm2/g)',
                'Pair Production In Nuclear Field (cm2/g)',
                'Pair Production In Electron Field (cm2/g)',
                'Total Attenuation With Coherent Scattering (cm2/g)',
                'Total Attenuation Without Coherent Scattering (cm2/g)')

COLUMNS_MEANING="\n".join(["\t%s - %s" % (i, meaning) for i, meaning in enumerate(COLUMNS_LEGEND)])

# Name of the configuration file. At the moment there is no chance to use
# something different from "$HOME/.pyxcomrc"
CFG_FILE = os.path.join(os.environ['HOME'], '.pyxcomrc')

# Default content for the configuration file: it supposes that the program xcom
# is installed under /opt
# Definition for XCOM path variables
XCOMDIR, XCOMBIN = "/opt/xcom/", "/opt/xcom/xcom"

def write_rc(XCOMDIR, XCOMBIN):
    """Pyxcom configuration file writer"""
    file(CFG_FILE, 'w').write("""# pyxcom configuration file
# It is rather simple: just set the the XCOMDIR and XCOMBIN variables
# to the correct values!
# For example if you have XCOM installed in the directory /opt/xcom and
# the executable is called 'XcOm' set these values to:
# XCOMDIR=/opt/xcom
# XCOMBIN=/opt/xcom/XcOm

XCOMDIR=%s
XCOMBIN=%s

""" % (XCOMDIR, XCOMBIN))

## option parsing functions
def helpcol():
    """USAGE: helpcol()

    Message printed when --helpcol flag is used.
    After displaying the message the program exits.
    """
    print "COLUMNS MEANING:\n%s\n" % COLUMNS_MEANING
    sys.exit()

def getopt_column(optarg):
    """USAGE: getopt_column(optarg)

    Called from the main file while checking from options.
    optarg should be in the form n1,..,nN.
    """
    try:
        # -9 to the get rid of edges column and start counting back from the end of the line
        column_list=[int(x)-9 for x in optarg.split(',')]
    except ValueError:
        ERROR_COLUMN_FLAG="""Syntax error in option --column
        The correct syntax is: --column n1,...,nN
        Notice the comma separated values!
        To see what the column number stands for run: pyxcom --helpcol
        """.strip()
        sys.exit()
    if False in [-9<x<0 for x in column_list]:
        sys.stderr.write('Columns must vary in the range 1-8!\n')
        sys.exit()
    else:
        return column_list
## End option parsing functions

## Configuration check
def ask_xcomdir():
    """USAGE: ask_xcomdir()

    Asks for the directory where xcom is installed until it is a correct directory
    """
    sys.stderr.write("Please enter the full path to the directory where XCOM executable is installed: ")
    XCOMDIR=raw_input()
    while not os.path.isdir(XCOMDIR):
        sys.stderr.write("%s appears not to be a valid directory!!!\n""" % XCOMDIR)
        sys.stderr.write("Please enter the full path to the directory where the XCOM executable is installed: ")
        XCOMDIR=raw_input()
    return XCOMDIR

def ask_xcombin(XCOMDIR):
    """USAGE: ask_xcombin(XCOMDIR)
    Asks for the name of the xcom executable until it is a file in the XCOMDIR directory.
    """
    sys.stderr.write("""Enter the name of the executable: """)
    XCOMBIN_=raw_input()
    XCOMBIN=os.path.join(XCOMDIR,XCOMBIN_)
    while not os.path.isfile(XCOMBIN):
        sys.stderr.write("""%s appears not to be a valid file!!!\n""" % XCOMBIN)
        sys.stderr.write("""Enter the name of the Xcom executable: """)
        XCOMBIN_=raw_input()
        XCOMBIN=os.path.join(XCOMDIR,XCOMBIN_)
    return XCOMBIN


def check_conf():
    """USAGE check_conf()

    Checks if the file CFG_FILE exists and is valid.
    If not provides it"""
    if not os.path.isfile(CFG_FILE):
        sys.stderr.write("""No configuration file found.\n""")
        sys.stderr.write("""Do you need to install xcom (wget needed)? [Y/n]""")
        DOWNLOADXCOM=raw_input()
        if DOWNLOADXCOM.lower() in ('', 'y', 'yes'):
            XCOMDIR, XCOMBIN = install_xcom()
        else:
            # Asking for path for an already installed version of xcom
            XCOMDIR=ask_xcomdir()
            XCOMBIN=ask_xcombin(XCOMDIR)
        lines=CFG_DEFAULT.splitlines(True)
        lines.append("XCOMDIR=%s\n" % XCOMDIR)
        lines.append("XCOMBIN=%s\n" % XCOMBIN)
        file(CFG_FILE, 'w').writelines(lines)
    else:
        # Check if XCOMDIR and XCOMBIN are set to correct values and
        # eventually corrects them
        XCOMDIR, XCOMBIN = read_conf()

def read_conf():
    """USAGE: read_conf()

    Reads the CFG_FILE and checks if it is correct.
    If it is not corrects it.
    """
    if not os.path.isfile(CFG_FILE): return '',''
    XCOMDIR, XCOMBIN = None, None
    for line in file(CFG_FILE):
        if '=' in line:
            key, value=line.split('=')
            if key.strip() == 'XCOMDIR':XCOMDIR=value[:-1].strip()
            elif key.strip() == 'XCOMBIN': XCOMBIN=value[:-1].strip()
    if XCOMDIR is None: XCOMDIR=ask_xcomdir()
    if XCOMBIN is None: XCOMBIN=ask_xcombin(XCOMDIR)
    write_rc(XCOMDIR, XCOMBIN)
    return XCOMDIR, XCOMBIN
## END Configuration check

## xcom installation
def install_xcom():
    """USAGE: install_xcom()

    Downloads, extracts, compiles xcom to the directory of your choice
    """
    # alias for sys.stderr.write
    say=sys.stdout.write
    warn=sys.stderr.write

    # warning on permission
    warn("""
    !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    Root privileges may be need to install xcom in directory where you do
    not have write permission.
    You can:
    1 - install xcom manually;
    2 - install as root or ask root to install the package;
    3 - run pyxcom as root to use this authomatized procedure.
    !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    """)

    # wgetting xcom
    say('Getting xcom with wget.\n')
    say('Enter a directory where the source will be temporarily stored[/tmp]:')
    TMPDIR=raw_input() or '/tmp'
    while not os.path.isdir(TMPDIR):
        try:
            say('Please create the directory and press enter or Ctrl-C to exit.')
            raw_input()
        except KeyboardInterrupt:
            sys.exit()
    os.system('wget %s -P %s' % (XCOM_URL, TMPDIR))

    # Extracting
    say("Where do you want to install xcom (absolute path) [/opt]? ")
    XCOM_PARENT_DIR=raw_input() or '/opt'
    while not os.path.isdir(XCOM_PARENT_DIR):
        try:
            say('Please create the directory and press enter or Ctrl-C to exit.')
            raw_input()
        except KeyboardInterrupt:
            sys.exit()
    say("Unpacking xcom\n")
    os.system('tar xzf %s/XCOM.tar.gz -C %s' % (TMPDIR, XCOM_PARENT_DIR))

    # remove the sources if needed
    say("""Do you want to remove the downloaded package? [Y/n]""")
    REMOVE=raw_input() or ''
    if REMOVE.lower() in ('', 'y', 'yes'): os.remove(os.path.join(TMPDIR,'XCOM.tar.gz'))

    # Rename XCOM directory (I like it this way)
    os.chdir(XCOM_PARENT_DIR)
    os.rename('XCOM', 'xcom')
    XCOMDIR=os.path.join(XCOM_PARENT_DIR, 'xcom')
    os.chdir(XCOMDIR)
    # Compile xcom
    os.system('g77 XCOM.f -o xcom')
    # Set xcom command
    XCOMBIN=os.path.join(XCOMDIR, 'xcom')
    return XCOMDIR, XCOMBIN
## END xcom installation

## cmds creation
# Here there  functions that decide what to ask to xcom to obtain
# correct data.
# One is for element and the other for compounds
def keV2MeV(keV):
    """Energy unit conversion.
    """
    return str(1.e-3*float(keV))

def cmds_energies(MeVs):
    """Adds the commands to specify the additional energies.
    Each element represents an interactions with xcom
    """
    cmds=('3', # Additional energies only
          '1', # Entry from keyboard
          "%s" % len(MeVs), # How many additional energies are wanted?
          '\n'.join(MeVs), # Energies in MeV
          'N', # Save additional energies in file? (Y/N)
          )
    return cmds

def cmds_output():
    """Adds the commands to specify we want to redirect te data on the standard output.
    Each element represents an interactions with xcom
    """
    cmds=('/dev/stdout', # Specify file on which output (cross section table) is to be stored. (Specification can include drive and path)
          '1', # No more output
          '')
    return cmds

def cmds_element(MeVs, flags):
    """Interacts with XCOM to have values for absortion for a given element
    using user supplied energies
    """
    cmds=["pyxcom",
          '1', # Elemental substance, specified by atomic number
          flags['Z'], # Atomic number of element
          '3', # Partial interaction coefficients and attenuation coefficients in cm2/g
          ]
    cmds.extend(cmds_energies(MeVs))
    cmds.extend(cmds_output())
    return cmds

def cmds_compound(MeVs, flags):
    """Interacts with XCOM to have values for absortion for a given compound
    """
    cmds=["pyxcom",
          '3', # Compound, specified by chemical formula
          flags['mat'], # Enter chemical formula for compound
         ]
    cmds.extend(cmds_energies(MeVs))
    cmds.extend(cmds_output())
    return cmds

def cmds_stdelement(flags):
    """Interacts with XCOM to have values for absortion for a given element
    using the standard energy grid
    """
    cmds=["pyxcom",
          '1', # Elemental substance, specified by atomic number
          flags['Z'], # Atomic number of element
          '3', # Partial interaction coefficients and attenuation coefficients in cm2/g
          '1', # Standard energy grid only
         ]
    cmds.extend(cmds_output())
    return cmds

def cmds_stdcompound(flags):
    cmds=["pyxcom",
          '3', # Compound, specified by chemical formula
          flags['mat'], # Enter chemical formula for compound
          '1', # Standard energy grid only
         ]
    cmds.extend(cmds_output())
    return cmds
## End cmds composition

def line2data(line, flags):
    """Extracts the needed data from the output lines"""
    # The correct lines are the ones containing 8 float at the end
    # Some lines can contain the label of the photo electric edge
    # at the beginning
    try:
        line_splitted=map(float, line.split()[-8:])
        if len(line_splitted) >=8:
            return "".join("%10s" % line_splitted[i] for i in flags['columns'])
    except ValueError:
        return None

def getcmds(MeVs, flags):
    if flags['standard'] or len(MeVs)==0:
        if flags['mat']:
            cmds=cmds_stdcompound(flags)
        else:
            cmds=cmds_stdelement(flags)
    else:
        if not flags['mat']:
            cmds=cmds_element(MeVs, flags)
        else:
            cmds=cmds_compound(MeVs, flags)
    return cmds

def cmds2data(cmds, flags):
    """takes the command line generated by cmds_$WHATYOUWANT functions
    and uses it to obtain values from xcom. The output of xcom is then
    parsed to extract only the information needed.
    """
    XCOMDIR, XCOMBIN = read_conf()
    OLDDIR=os.getcwd()
    os.chdir(XCOMDIR)
    xcom_output=os.popen('echo "%s"|%s ' % ("\n".join(cmds), XCOMBIN)).readlines()
    os.chdir(OLDDIR)
    # Getting only the total attenuation
    parsed_text=[line2data(line, flags) for line in xcom_output]
    parsed_text=[x for x in parsed_text if x is not None]
    return "\n".join(parsed_text)

def headers(flags, cmds):
    """Returns a header with the excuted xcom commands and the data descriptio
    """
    field1 = "# XCOM COMMANDS:\n"
    commented_cmds=['# %s' % x for x in cmds]
    commented_cmds="\n".join(commented_cmds)
    field2 = '\n# COLUMNS DESCRIPTION:\n'
    col_str='\n'.join(["# %s: %s" % (i+1, COLUMNS_LEGEND[col]) for i, col in enumerate(flags['columns'])])
    field3 = '\n#\n#\n# DATA:'
    header = "%s%s%s%s%s\n" % (field1, commented_cmds, field2, col_str, field3)
    return header

def wxapp(args, flags):
    from pyxcom import wxgui
    gui=wxgui.PyxcomApp(-1)
    gui.MainLoop()

def qtapp(args, flags):
    from pyxcom import qtApp, qtgui
    gui=qtgui.QApplication(args)
    app=qtApp.QtApp()
    app.show()
    gui.setMainWidget(app)
    gui.exec_loop()

def tui(args, flags):
    """Text User Interface
    """
    check_conf()
    if flags['range']:
        Emin, Emax = map(int, flags['range'][1:-1].split(':'))
        MeVs=map(keV2MeV, range(Emin, Emax))
    else:
        MeVs=map(keV2MeV, args)
    cmds=getcmds(MeVs, flags)
    data=cmds2data(cmds, flags)
    if flags['quiet']:return data
    else: return headers(flags, cmds)+data
