## -----------------------------------
## This is a global library for pyxcom
## -----------------------------------
## Copyright (c) 2004-2007 Alessandro Pisa <alessandro...pisa@@@gmail...com>
## All rights reserved.
##
## Redistribution and use in source and binary forms, with or without
## modification, are permitted provided that the following conditions
## are met:
##
## 1. Redistributions of source code must retain the above copyright
##    notice, this list of conditions and the following disclaimer.
## 2. Redistributions in binary form must reproduce the above copyright
##    notice, this list of conditions and the following disclaimer in the
##    documentation and/or other materials provided with the distribution.
##
## THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
## IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
## OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
## IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
## INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
## NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
## DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
## THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
## (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
## THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

from pyxcom import qtgui, pxglob
class QtApp(qtgui.PyxcomGui):
    def __init__(self):
        qtgui.PyxcomGui.__init__(self)
        self.connect(self.calculateButton,qtgui.SIGNAL("clicked()"),self.qtCalculate)
        self.connect(self.allButton,qtgui.SIGNAL("clicked()"),self.qtSelectAll)
        self.connect(self.noneButton,qtgui.SIGNAL("clicked()"),self.qtSelectNone)
        self.connect(self.invertButton,qtgui.SIGNAL("clicked()"),self.qtSelectInvert)
        self.connect(self.saveButton,qtgui.SIGNAL("clicked()"),self.saveData)
        self.connect(self.nrgButton,qtgui.SIGNAL("clicked()"),self.loadNrgFile)

    def colRBs(self):
        self.rBs=(self.colRB1,
                  self.colRB2,
                  self.colRB3,
                  self.colRB4,
                  self.colRB5,
                  self.colRB6,
                  self.colRB7,
                  self.colRB8,
                 )
        for rB in self.rBs: yield rB

    def qtSelectInvert(self):
        for rB in self.colRBs(): rB.toggle()

    def qtSelectNone(self):
        for rB in self.colRBs(): rB.setChecked(0)

    def qtSelectAll(self):
        [rB.setChecked(1) for rB in self.colRBs()]

    def cols(self):
        rBs=[rB.isChecked() for rB in self.colRBs()]
        return [i-8 for i,c in enumerate(rBs) if c is True]

    def qtCalculate(self):
        # Collecting basic info
        flags={'range':None, 'X':False, 'standard':False, 'quiet':True}
        rBs=[rB.isChecked() for rB in self.colRBs()]
        flags["columns"]=[i-8 for i,c in enumerate(rBs) if c is True]

        # Element or material?
        activeTab=self.tabEleMat.currentPageIndex()
        if activeTab==0:
            flags["Z"]=str(self.ZspinBox.value())
            flags["mat"]=False
        elif activeTab==1:
            flags["mat"]=str(self.formulaCBox.currentText())

        # Energy policy
        activeTab=self.tabEnergy.currentPageIndex()
        if activeTab==0:
            flags['standard'], keVs = True,[]
        elif activeTab==1:
            keVs=[x for x in str(self.lineEdit5.text()).split() if x.isdigit()]
        elif activeTab==2:
            Emin=self.lineEdit3.text()
            if str(Emin).isdigit(): Emin=int(Emin)
            else:Emin=1
            Emax=self.lineEdit3_2.text()
            if str(Emax).isdigit(): Emax=int(Emax)
            else:Emin=1000
            keVs=map(str, range(Emin, Emax+1))
        elif activeTab==3:
            keVs=[]
        MeVs=map(pxglob.keV2MeV, keVs)

        # Getting commands
        cmds=pxglob.getcmds(MeVs, flags)
        self.textBrowser1_2.setText("\n".join(cmds))
        self.tabWidget4.setCurrentPage(2)
        # Getting data
        data=pxglob.cmds2data(cmds, flags)
        self.textBrowser1.setText(data)
        self.tabWidget4.setCurrentPage(1)

    def loadNrgFile(self):
        self.lineEdit5.setText(file(qtgui.QFileDialog.getOpenFileName()).read())
        self.tabEnergy.setCurrentPage(1)
        self.qtCalculate()

    def saveData(self):
        data=self.textBrowser1.selectedText()
        fileName = qtgui.QFileDialog.getSaveFileName()
        file(fileName, 'w').write(data)
