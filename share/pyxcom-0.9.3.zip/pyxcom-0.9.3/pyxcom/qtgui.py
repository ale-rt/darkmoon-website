# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'qtgui.ui'
#
# Created: Mon Dec 17 11:38:02 2007
#      by: The PyQt User Interface Compiler (pyuic) 3.17.3
#
# WARNING! All changes made in this file will be lost!
## Copyright (c) 2004-2007 Alessandro Pisa <alessandro...pisa@@@gmail...com>
## All rights reserved.
##
## Redistribution and use in source and binary forms, with or without
## modification, are permitted provided that the following conditions
## are met:
##
## 1. Redistributions of source code must retain the above copyright
##    notice, this list of conditions and the following disclaimer.
## 2. Redistributions in binary form must reproduce the above copyright
##    notice, this list of conditions and the following disclaimer in the
##    documentation and/or other materials provided with the distribution.
##
## THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
## IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
## OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
## IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
## INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
## NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
## DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
## THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
## (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
## THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


from qt import *


class PyxcomGui(QDialog):
    def __init__(self,parent = None,name = None,modal = 0,fl = 0):
        QDialog.__init__(self,parent,name,modal,fl)

        if not name:
            self.setName("PyxcomGui")

        self.setSizeGripEnabled(0)

        PyxcomGuiLayout = QVBoxLayout(self,11,6,"PyxcomGuiLayout")

        self.tabWidget4 = QTabWidget(self,"tabWidget4")
        self.tabWidget4.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding,0,0,self.tabWidget4.sizePolicy().hasHeightForWidth()))
        self.tabWidget4.setMinimumSize(QSize(0,300))
        self.tabWidget4.setTabPosition(QTabWidget.Bottom)
        self.tabWidget4.setTabShape(QTabWidget.Rounded)

        self.TabPage = QWidget(self.tabWidget4,"TabPage")

        self.colRB1 = QRadioButton(self.TabPage,"colRB1")
        self.colRB1.setGeometry(QRect(108,42,347,19))
        self.colRB1.setChecked(1)

        self.colRB2 = QRadioButton(self.TabPage,"colRB2")
        self.colRB2.setGeometry(QRect(108,67,347,19))
        self.colRB2.setChecked(1)

        self.allButton = QPushButton(self.TabPage,"allButton")
        self.allButton.setGeometry(QRect(10,92,82,26))

        self.colRB3 = QRadioButton(self.TabPage,"colRB3")
        self.colRB3.setGeometry(QRect(108,92,347,19))
        self.colRB3.setChecked(1)

        self.colRB4 = QRadioButton(self.TabPage,"colRB4")
        self.colRB4.setGeometry(QRect(108,117,347,19))
        self.colRB4.setChecked(1)

        self.noneButton = QPushButton(self.TabPage,"noneButton")
        self.noneButton.setGeometry(QRect(10,126,82,26))

        self.colRB5 = QRadioButton(self.TabPage,"colRB5")
        self.colRB5.setGeometry(QRect(108,142,347,19))
        self.colRB5.setChecked(1)

        self.invertButton = QPushButton(self.TabPage,"invertButton")
        self.invertButton.setGeometry(QRect(10,160,82,26))

        self.colRB6 = QRadioButton(self.TabPage,"colRB6")
        self.colRB6.setGeometry(QRect(108,167,347,19))
        self.colRB6.setChecked(1)

        self.colRB7 = QRadioButton(self.TabPage,"colRB7")
        self.colRB7.setGeometry(QRect(108,192,347,19))
        self.colRB7.setChecked(1)

        self.colRB8 = QRadioButton(self.TabPage,"colRB8")
        self.colRB8.setGeometry(QRect(108,217,347,19))
        self.colRB8.setChecked(1)
        self.tabWidget4.insertTab(self.TabPage,QString.fromLatin1(""))

        self.tab = QWidget(self.tabWidget4,"tab")
        tabLayout = QVBoxLayout(self.tab,11,6,"tabLayout")

        self.textBrowser1 = QTextBrowser(self.tab,"textBrowser1")
        self.textBrowser1.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.Expanding,4,4,self.textBrowser1.sizePolicy().hasHeightForWidth()))
        textBrowser1_font = QFont(self.textBrowser1.font())
        textBrowser1_font.setFamily("Bitstream Vera Sans Mono")
        textBrowser1_font.setPointSize(6)
        self.textBrowser1.setFont(textBrowser1_font)
        self.textBrowser1.setMargin(0)
        self.textBrowser1.setWordWrap(QTextBrowser.NoWrap)
        tabLayout.addWidget(self.textBrowser1)

        layout7 = QHBoxLayout(None,0,6,"layout7")

        self.textLabel1 = QLabel(self.tab,"textLabel1")
        layout7.addWidget(self.textLabel1)

        self.saveButton = QPushButton(self.tab,"saveButton")
        layout7.addWidget(self.saveButton)

        self.selectAllButton = QPushButton(self.tab,"selectAllButton")
        layout7.addWidget(self.selectAllButton)
        tabLayout.addLayout(layout7)
        self.tabWidget4.insertTab(self.tab,QString.fromLatin1(""))

        self.tab_2 = QWidget(self.tabWidget4,"tab_2")
        tabLayout_2 = QVBoxLayout(self.tab_2,11,6,"tabLayout_2")

        self.textBrowser1_2 = QTextBrowser(self.tab_2,"textBrowser1_2")
        tabLayout_2.addWidget(self.textBrowser1_2)
        self.tabWidget4.insertTab(self.tab_2,QString.fromLatin1(""))
        PyxcomGuiLayout.addWidget(self.tabWidget4)

        self.tabEnergy = QTabWidget(self,"tabEnergy")
        self.tabEnergy.setTabPosition(QTabWidget.Bottom)

        self.tab_3 = QWidget(self.tabEnergy,"tab_3")
        tabLayout_3 = QHBoxLayout(self.tab_3,11,6,"tabLayout_3")

        self.textLabel8 = QLabel(self.tab_3,"textLabel8")
        self.textLabel8.setSizePolicy(QSizePolicy(QSizePolicy.Maximum,QSizePolicy.Maximum,0,0,self.textLabel8.sizePolicy().hasHeightForWidth()))
        tabLayout_3.addWidget(self.textLabel8)
        self.tabEnergy.insertTab(self.tab_3,QString.fromLatin1(""))

        self.tab_4 = QWidget(self.tabEnergy,"tab_4")
        tabLayout_4 = QVBoxLayout(self.tab_4,11,6,"tabLayout_4")

        self.groupBox2 = QGroupBox(self.tab_4,"groupBox2")
        self.groupBox2.setColumnLayout(0,Qt.Vertical)
        self.groupBox2.layout().setSpacing(6)
        self.groupBox2.layout().setMargin(11)
        groupBox2Layout = QVBoxLayout(self.groupBox2.layout())
        groupBox2Layout.setAlignment(Qt.AlignTop)

        self.lineEdit5 = QLineEdit(self.groupBox2,"lineEdit5")
        self.lineEdit5.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.MinimumExpanding,0,0,self.lineEdit5.sizePolicy().hasHeightForWidth()))
        self.lineEdit5.setDragEnabled(1)
        groupBox2Layout.addWidget(self.lineEdit5)
        tabLayout_4.addWidget(self.groupBox2)
        self.tabEnergy.insertTab(self.tab_4,QString.fromLatin1(""))

        self.TabPage_2 = QWidget(self.tabEnergy,"TabPage_2")
        TabPageLayout = QHBoxLayout(self.TabPage_2,11,6,"TabPageLayout")

        self.groupBox1 = QGroupBox(self.TabPage_2,"groupBox1")
        self.groupBox1.setColumnLayout(0,Qt.Vertical)
        self.groupBox1.layout().setSpacing(6)
        self.groupBox1.layout().setMargin(11)
        groupBox1Layout = QVBoxLayout(self.groupBox1.layout())
        groupBox1Layout.setAlignment(Qt.AlignTop)

        layout6 = QHBoxLayout(None,0,6,"layout6")

        self.textLabel7 = QLabel(self.groupBox1,"textLabel7")
        layout6.addWidget(self.textLabel7)

        self.lineEdit3 = QLineEdit(self.groupBox1,"lineEdit3")
        layout6.addWidget(self.lineEdit3)

        self.textLabel7_2 = QLabel(self.groupBox1,"textLabel7_2")
        layout6.addWidget(self.textLabel7_2)

        self.lineEdit3_2 = QLineEdit(self.groupBox1,"lineEdit3_2")
        layout6.addWidget(self.lineEdit3_2)
        groupBox1Layout.addLayout(layout6)
        TabPageLayout.addWidget(self.groupBox1)
        self.tabEnergy.insertTab(self.TabPage_2,QString.fromLatin1(""))

        self.TabPage_3 = QWidget(self.tabEnergy,"TabPage_3")
        TabPageLayout_2 = QHBoxLayout(self.TabPage_3,11,6,"TabPageLayout_2")

        self.groupBox2_2 = QGroupBox(self.TabPage_3,"groupBox2_2")
        self.groupBox2_2.setColumnLayout(0,Qt.Vertical)
        self.groupBox2_2.layout().setSpacing(6)
        self.groupBox2_2.layout().setMargin(11)
        groupBox2_2Layout = QHBoxLayout(self.groupBox2_2.layout())
        groupBox2_2Layout.setAlignment(Qt.AlignTop)

        layout9 = QHBoxLayout(None,0,6,"layout9")

        self.fileSelector = QLineEdit(self.groupBox2_2,"fileSelector")
        self.fileSelector.setSizePolicy(QSizePolicy(QSizePolicy.Expanding,QSizePolicy.MinimumExpanding,0,0,self.fileSelector.sizePolicy().hasHeightForWidth()))
        self.fileSelector.setDragEnabled(1)
        layout9.addWidget(self.fileSelector)

        self.nrgButton = QPushButton(self.groupBox2_2,"nrgButton")
        layout9.addWidget(self.nrgButton)
        groupBox2_2Layout.addLayout(layout9)
        TabPageLayout_2.addWidget(self.groupBox2_2)
        self.tabEnergy.insertTab(self.TabPage_3,QString.fromLatin1(""))
        PyxcomGuiLayout.addWidget(self.tabEnergy)

        layout10 = QHBoxLayout(None,0,6,"layout10")

        self.tabEleMat = QTabWidget(self,"tabEleMat")
        self.tabEleMat.setMinimumSize(QSize(300,0))
        self.tabEleMat.setTabPosition(QTabWidget.Bottom)

        self.tab_5 = QWidget(self.tabEleMat,"tab_5")

        self.ZspinBox = QSpinBox(self.tab_5,"ZspinBox")
        self.ZspinBox.setGeometry(QRect(10,10,80,21))
        self.ZspinBox.setMaxValue(100)
        self.ZspinBox.setMinValue(1)
        self.tabEleMat.insertTab(self.tab_5,QString.fromLatin1(""))

        self.tab_6 = QWidget(self.tabEleMat,"tab_6")

        self.formulaCBox = QComboBox(0,self.tab_6,"formulaCBox")
        self.formulaCBox.setGeometry(QRect(120,10,85,21))
        self.formulaCBox.setAcceptDrops(1)
        self.formulaCBox.setEditable(1)
        self.formulaCBox.setAutoCompletion(1)
        self.tabEleMat.insertTab(self.tab_6,QString.fromLatin1(""))
        layout10.addWidget(self.tabEleMat)
        spacer7 = QSpacerItem(69,20,QSizePolicy.Expanding,QSizePolicy.Minimum)
        layout10.addItem(spacer7)

        self.calculateButton = QPushButton(self,"calculateButton")
        layout10.addWidget(self.calculateButton)

        self.exitButton = QPushButton(self,"exitButton")
        layout10.addWidget(self.exitButton)
        PyxcomGuiLayout.addLayout(layout10)

        self.languageChange()

        self.resize(QSize(548,540).expandedTo(self.minimumSizeHint()))
        self.clearWState(Qt.WState_Polished)

        self.connect(self.exitButton,SIGNAL("clicked()"),self.close)
        self.connect(self.selectAllButton,SIGNAL("clicked()"),self.textBrowser1.selectAll)


    def languageChange(self):
        self.setCaption(self.__tr("PyxcomGui"))
        self.colRB1.setText(self.__tr("1: Photon Energy (MeV)"))
        self.colRB2.setText(self.__tr("2: Coherent Scattering (cm2/g)"))
        self.allButton.setText(self.__tr("&All"))
        self.allButton.setAccel(QKeySequence(self.__tr("Alt+A")))
        self.colRB3.setText(self.__tr("3: Incoherent Scattering (cm2/g)"))
        self.colRB4.setText(self.__tr("4: Photoelectric Absorption (cm2/g)"))
        self.noneButton.setText(self.__tr("&None"))
        self.noneButton.setAccel(QKeySequence(self.__tr("Alt+N")))
        self.colRB5.setText(self.__tr("5: Pair Production In Nuclear Field (cm2/g)"))
        self.invertButton.setText(self.__tr("&Invert"))
        self.invertButton.setAccel(QKeySequence(self.__tr("Alt+I")))
        self.colRB6.setText(self.__tr("6: Pair Production In Electron Field (cm2/g)"))
        self.colRB7.setText(self.__tr("7: Total Attenuation With Coherent Scattering (cm2/g)"))
        self.colRB8.setText(self.__tr("8: Total Attenuation Without Coherent Scattering (cm2/g)"))
        self.tabWidget4.changeTab(self.TabPage,self.__tr("Data selection"))
        self.textLabel1.setText(self.__tr("Use save button to save selected data on file"))
        self.saveButton.setText(self.__tr("&Save selected..."))
        self.saveButton.setAccel(QKeySequence(self.__tr("Alt+S")))
        self.selectAllButton.setText(self.__tr("select &All"))
        self.selectAllButton.setAccel(QKeySequence(self.__tr("Alt+A")))
        self.tabWidget4.changeTab(self.tab,self.__tr("Data"))
        self.tabWidget4.changeTab(self.tab_2,self.__tr("XCOM commands"))
        self.textLabel8.setText(self.__tr("<p align=\"center\">Just click <br>\n"
"<font size=\"+1\"><u>C</u>alculate </font><br>\n"
"to obtain the values for the  <br>\n"
"XCOM standard energy grid</p>"))
        self.tabEnergy.changeTab(self.tab_3,self.__tr("Standard Grid"))
        self.groupBox2.setTitle(self.__tr("Enter energies by hand (keV)"))
        self.lineEdit5.setText(self.__tr("100 511 1000"))
        self.tabEnergy.changeTab(self.tab_4,self.__tr("Energy list"))
        self.groupBox1.setTitle(self.__tr("set energy limits (keV)"))
        self.textLabel7.setText(self.__tr("<p align=\"Zright\">minimum Energy</p>"))
        self.lineEdit3.setText(self.__tr("1"))
        self.textLabel7_2.setText(self.__tr("<p align=\"Zright\">maximum Energy</p>"))
        self.lineEdit3_2.setText(self.__tr("1000"))
        self.tabEnergy.changeTab(self.TabPage_2,self.__tr("Energy range"))
        self.groupBox2_2.setTitle(self.__tr("Load energies from ASCII file"))
        self.nrgButton.setText(self.__tr("Browse ..."))
        self.tabEnergy.changeTab(self.TabPage_3,self.__tr("Energies from file"))
        self.tabEleMat.changeTab(self.tab_5,self.__tr("Atomic Number"))
        self.formulaCBox.clear()
        self.formulaCBox.insertItem(QString.null)
        self.formulaCBox.insertItem(self.__tr("CH4"))
        self.formulaCBox.insertItem(self.__tr("H2"))
        self.formulaCBox.insertItem(self.__tr("H2O"))
        self.formulaCBox.insertItem(self.__tr("NaCl"))
        self.formulaCBox.insertItem(self.__tr("NaOH"))
        self.formulaCBox.insertItem(self.__tr("O2"))
        self.tabEleMat.changeTab(self.tab_6,self.__tr("Chemical Formula"))
        self.calculateButton.setText(self.__tr("&Calculate"))
        self.calculateButton.setAccel(QKeySequence(self.__tr("Alt+C")))
        self.exitButton.setText(self.__tr("&Exit"))
        self.exitButton.setAccel(QKeySequence(self.__tr("Alt+E")))


    def __tr(self,s,c = None):
        return qApp.translate("PyxcomGui",s,c)
