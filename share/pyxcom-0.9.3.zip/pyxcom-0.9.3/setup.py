#!/usr/bin/env python
from distutils.core import setup

setup(name = "pyxcom",
      version = "0.9.3",
      description = "pyxcom - a Python interface to xcom",
      author = "Alessandro Pisa",
      author_email = "alessandro...pisa@@@gmail...com",
      url = "http://darkmoon.altervista.org",
      packages = ["pyxcom", ""],
      scripts = ['scripts/pyxcom'],
      long_description = """
pyxcom is both a text and graphical (wxPyhton or PyQT) user interface to the NIST
program XCOM.
It is used to make easy the work with XCOM simplyfing parameters input and
displaying the output in a format that is compatible with plotting programs
like gnuplot.
"""
)
